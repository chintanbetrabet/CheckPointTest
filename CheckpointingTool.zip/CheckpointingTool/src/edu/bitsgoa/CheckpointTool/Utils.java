/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.bitsgoa.CheckpointTool;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author chintan
 */
public class Utils {
    public static void writeSystemCommandToFile(BufferedReader buffer, String outString) {
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(outString);
            String line;
            while ((line = buffer.readLine()) != null) {
                fileWriter.write(line);
                fileWriter.write("\n");
            }
            buffer.close();
        } catch (IOException ex) {
            Logger.getLogger(Utils.class.getName()).log(Level.SEVERE, null, ex);
        } 
         finally {
            try {
                fileWriter.close();
            }
            catch (IOException ex) {
            Logger.getLogger(Utils.class.getName()).log(Level.SEVERE, null, ex);
        } 
            
        }
    }
    public static BufferedReader runProcess(String command) {
        try {
            Process process;
            process = Runtime.getRuntime().exec(command);
            //process.waitFor();
            BufferedReader buffer = new BufferedReader(new InputStreamReader(process.getInputStream()));
            return buffer;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {

        }
    }
    public static String readFileToString(String filename) {
        String output = "";
        BufferedReader br = null;
        FileReader fr = null;

        try {

            fr = new FileReader(filename);
            br = new BufferedReader(fr);

            String sCurrentLine;

            br = new BufferedReader(new FileReader(filename));

            while ((sCurrentLine = br.readLine()) != null) {
                output = output.concat(sCurrentLine);
            }

        } catch (IOException e) {

            e.printStackTrace();

        } finally {

            try {

                if (br != null) {
                    br.close();
                }

                if (fr != null) {
                    fr.close();
                }

            } catch (IOException ex) {

                ex.printStackTrace();

            }

        }
        return output;
    }
    
}
