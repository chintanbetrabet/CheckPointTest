/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.bitsgoa.CheckpointTool;

/**
 *
 * @author chintan
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.NotFoundException;

/**
 *
 * @author chintan
 *
 *
 */
public class MethodParser {

    public static TreeMap<String, HashSet<String>> callgraphClassesAndTheirMethods(String filename) throws IOException {
        BufferedReader read;
        TreeMap<String, HashSet<String>> tm = new TreeMap<>();
        try {

            read = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = read.readLine()) != null) {
                if (line.startsWith("M:") && line.contains("(I)")) {
                    String temp = line.split(":")[1];
                    String classname = temp;

                    //temp = line.split("\\)")[1];
                    String methodname = line.split("[)]")[1];
                    //System.out.println(classname+" "+methodname);
                    if (!tm.containsKey(classname)) {
                        HashSet<String> methodset = new HashSet<>();
                        methodset.add(methodname);
                        tm.put(classname, methodset);
                    } else {
                        HashSet<String> methodset = tm.get(classname);
                        methodset.add(methodname);
                        tm.remove(classname);
                        tm.put(classname, methodset);
                    }

                }
            }
            read.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MethodParser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MethodParser.class.getName()).log(Level.SEVERE, null, ex);
        }

        return tm;
    }

    

       public static void modifyJarUsingCallGraph(ClassPool pool, String callgraphFilename, String destination, String checkpointingCode, String jarName) {
        try {
            
            TreeMap<String, HashSet<String>> classWithMethods;
            classWithMethods = MethodParser.callgraphClassesAndTheirMethods(callgraphFilename);

            Set set = classWithMethods.entrySet();
            Iterator i = set.iterator();
            CtClass ctClass = null;
            while (i.hasNext()) {
                Map.Entry me = (Map.Entry) i.next();
                String classname = (String) me.getKey();
                ctClass = pool.get(classname);
                for (CtMethod method : ctClass.getDeclaredMethods()) {
                    method = ctClass.getDeclaredMethod(method.getName());
                    ctClass.defrost();
                    MethodInstrumenter.modifyCalledMethodsFromMethod(ctClass, pool, method, destination, checkpointingCode, jarName);
                    ctClass.writeFile(destination);

                }
            }
            if (ctClass != null) {
                //System.out.println("HI MODIfy jar using call");
                ctClass.writeFile();
                //System.out.println("Need update on "+ctClass.getName());
                JarHandler.writeJar(ctClass, pool, jarName);
            }
        } catch (NotFoundException | IOException | CannotCompileException ex) {
            Logger.getLogger(MethodParser.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

       
}
