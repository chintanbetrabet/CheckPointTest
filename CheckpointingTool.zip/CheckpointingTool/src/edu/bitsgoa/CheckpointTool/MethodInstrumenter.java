/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.bitsgoa.CheckpointTool;

/**
 *
 * @author chintan
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;

public class MethodInstrumenter {
   
    public static void modifyCalledMethodsFromMethod(CtClass ctClass, ClassPool cp, CtMethod method, String destination, String checkpointingCode, String jarName) {
        try {
            
            ctClass.defrost();
            //ADD checkpoint method here
            HashMap<Integer, String> lines;
            lines = new HashMap<>();
            
            method.instrument(
                    new ExprEditor() {
                @Override
                public void edit(final MethodCall m) throws CannotCompileException {

                    lines.put(m.getLineNumber(), m.getMethodName());
                    System.out.println(m.getClassName() + "       " + m.getMethodName());
                   if(m.getMethodName().equals("createStatement"))
                    {
                        m.replace("java.sql.Connection con1 = null;"
                                + "con1=java.sql.DriverManager.getConnection(  \"jdbc:mysql://localhost:3306/LARGE?autoReconnect=true\",\"root\",\"J!4192chb\");"
                                + "$0=con1;"
                                
                                
                                + "$_ = $proceed($$);");
                    }
                   else if(m.getMethodName().equals("prepareStatement"))
                    {
                        m.replace("java.sql.Connection con1 = null;"
                               + "con1=java.sql.DriverManager.getConnection( \"jdbc:mysql://localhost:3306/LARGE?autoReconnect=true\",\"root\",\"J!4192chb\");"
                                + "$0=con1;"
                                
                                
                                + "$_ = $proceed($$);");
                    }
                    
                    else if (m.getMethodName().equals("executeUpdate"))
                    {

                        m.replace("$_ = $proceed($$);");
                    }
                    else if (m.getClassName().equals("java.sql.DriverManager")
                            && m.getMethodName().equals("getConnection")) {

                       m.replace("String s=$1;System.out.println(\"Connection called called by\"+\" \" +$1);"
                                + "if (!s.contains(\"autoReconnect\"))\n"
                                + "{\n"
                                + "    if(s.contains(\"?\"))\n"
                                + "    {\n"
                                + "        s=s+\"&&autoReconnect=true&&maxReconnects=3\";\n"
                                + "    }\n"
                                + "    else\n"
                                + "    {\n"
                                + "        s=s+\"?autoReconnect=true&&maxReconnects=3\";\n"
                                + "    }\n"
                                + "}\n"
                                + "$1=s;"
                                + "System.out.println(\"URL=\"+s)\n;"
                                + "$_ = $proceed($$);"
                        );
                    }

//                    System.out.println(m.getClassName() + "." + m.getMethodName());
                }
            });
            for (Integer ln : lines.keySet()) {
                //  method.insertAt(ln, "System.out.println(\"Will Call Checkpoint before " + lines.get(ln) + "\");");
                 if (lines.get(ln).equals("executeUpdate")) {
                    method.insertAt(ln + 1, String.format(checkpointingCode, lines.get(ln)));
                }
                //method.insertAt(ln, "Parasite.checkpoint(" + lines.get(ln) + ");");
            }

            //ctClass.writeFile(destination);
            //System.out.println("writing class"+ctClass.getName());
            JarHandler.writeJar(ctClass, cp, jarName);
        } catch (CannotCompileException ex) {
            Logger.getLogger(MethodInstrumenter.class.getName()).log(Level.SEVERE, null, ex);
        } 
        

    }
    public static void main(String a[]) throws NotFoundException
    {
        MainDriver.main(null);
    }

}
