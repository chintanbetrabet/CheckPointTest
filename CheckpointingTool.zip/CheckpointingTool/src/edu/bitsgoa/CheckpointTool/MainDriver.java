/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.bitsgoa.CheckpointTool;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javassist.ClassPool;
import javassist.NotFoundException;

/**
 *
 * @author chintan
 */
public class MainDriver {
    
    public static void main(String args[]) throws NotFoundException {
        System.out.println("YO");
        Scanner configScanner = null;
        try {
            configScanner = new Scanner(new File("./config"));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MethodParser.class.getName()).log(Level.SEVERE, null, ex);
        }
        HashMap<String,String> configMap=new HashMap<>();
        while(configScanner.hasNext())
        {
            String configData=configScanner.nextLine();
            String key,value;
            key=configData.split(":")[0];
            value=configData.split(":")[1];
            configMap.put(key, value);
        }
        System.out.println(configMap);
        String jarName = configMap.get("JAR_PATH");
        String callgraphFile = "callgraph_output";
        String callgraphCreateCommand = configMap.get("CALLGRAPH_LOCATION");
        String destination = configMap.get("OUTPUT_LOCATION");
        //String checkpointCode = readFileToString("../config/checkpointCodeJava");
        String checkpointCommand = configMap.get("CHECKPOINT_COMMAND");
        
        
        String checkpointCode = "try"
                + "        {"
                + "         System.out.println(\"I want a CHKPT after \");"
                + "        String command = \"%s\";"
                + "        Process process = Runtime.getRuntime().exec(command);process.waitFor();"
                + "        } catch (java.io.IOException ex) {"
                + "            System.out.println(\"Glitch\");"
                + "        }"
                + " ";

        checkpointCode = String.format(checkpointCode, checkpointCommand);
        // checkpointCode=String.format(checkpointCode, methodName);

        //System.out.println(checkpointCode);
        ClassPool pool = ClassPool.getDefault();
        try {
            pool.appendClassPath(jarName);
        } catch (NotFoundException ex) {
            Logger.getLogger(MethodParser.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       Utils.writeSystemCommandToFile(Utils.runProcess(callgraphCreateCommand + " "+jarName), callgraphFile);
       MethodParser.modifyJarUsingCallGraph(pool, callgraphFile, destination, checkpointCode, jarName);
        System.out.println("Finished");
    }
    
}
