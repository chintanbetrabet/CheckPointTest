# To demonstrate, do:  make check    [Checkpoints every 5 seconds]

# The name will be the same as the current directory name.
# By default, your resulting plugin library will have this name.
LIBNAME="libdmtcp_plugin-to-announce-events"

# As you add new files to your plugin library, add the object file names here.
LIBOBJS="plugin-to-announce-events.o"

# Modify if your DMTCP_ROOT is located elsewhere.
#ifndef DMTCP_ROOT
  DMTCP_ROOT="../.."
#endif 
DMTCP_INCLUDE=${DMTCP_ROOT}/include

gcc -fPIC -I$DMTCP_ROOT/include -I/usr/include/mysql -c -o plugin-to-announce-events.o  plugin-to-announce-events.c `mysql_config --cflags --libs`
gcc -shared -fPIC -I$DMTCP_ROOT/include -I/usr/include/mysql -o libdmtcp_plugin-to-announce-events.so plugin-to-announce-events.o 
sh sql_compile.sh chkptplugin


DEMO_PORT=7781

$DMTCP_ROOT/bin/dmtcp_command --quit --quiet  --coord-port $DEMO_PORT 2>/dev/null || true
$DMTCP_ROOT/bin/dmtcp_launch --coord-port $DEMO_PORT --with-plugin $(pwd)/$LIBNAME.so --ckpt-signal 10 java -jar /home/chintan/Downloads/SOP/FinalProjectStructure/Test/dist/Test.jar
