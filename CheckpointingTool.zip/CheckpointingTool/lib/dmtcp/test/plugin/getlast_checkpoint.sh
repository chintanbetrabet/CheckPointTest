#ls -lrt
myfile=$(ls  -t | grep dmtcp | grep applic | tail -1)
ls  -t | grep dmtcp | grep applic > f1
v=$(wc -l f1 | awk {'print $1'})
v=$((v-1))
tail -n $v f1 > f2
cat f2 > f1
rm f2
#echo "kept only "$myfile

while read line;
do
echo "delete "$line
rm $line
done < f1



