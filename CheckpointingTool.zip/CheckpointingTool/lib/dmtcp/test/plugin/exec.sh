python gen_queries.py > /home/chintan/Downloads/FinalProjectStructure/Test/query_file

make clean
make check

