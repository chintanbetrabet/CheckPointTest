#include<string.h>
#include<mysql/mysql.h>
#include<stdio.h>
int main()
{
 char query[1000],use_query[1000];
	char command[1000];
	int show=0;
	int q=1000;
	int qc=0;
	int chkpt=0;
	char passwd[100],DATABASE[100],user[100],TABLE[100];
	char host[100];
	char query_file[100];
	strcpy(host,"localhost");
	strcpy(user,"root");
	strcpy(passwd,"J!4192chb");
	strcpy(DATABASE,"LARGE");
	strcpy(TABLE,"user_details");
	strcpy(query_file,"queries");
		MYSQL *con =mysql_init(NULL);
		if(con==NULL)printf("FAIL\n");
		else printf("INIT success\n");

		if(mysql_real_connect(con,"localhost",user,passwd,NULL,0,NULL,0))
		{
			printf("Connect success\n");
		}
		else{
			printf("FAIL CONNECT");exit(1);
		}
	
}
