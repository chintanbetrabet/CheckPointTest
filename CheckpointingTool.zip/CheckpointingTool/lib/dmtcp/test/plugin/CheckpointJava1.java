/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package checkpointjava;

/**
 *
 * @author chintan
 */
import java.sql.*;  
import java.io.*;
import java.util.Random;
import java.util.*;

class CheckpointJava{  

 static Connection con;
 static String URL,username,password;
public static int qc=0;
 
 private static BufferedReader runProcess(String command) 
	{
		try{
			Process process;
			process = Runtime.getRuntime().exec(command);
			//process.waitFor();
			BufferedReader buffer = new BufferedReader(new InputStreamReader(process.getInputStream()));
			return buffer;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;	
		}
		finally
		{

		}
	}
	
	private static void printProcessOutput(BufferedReader buffer)
	{
		try{
			String line="";
			while((line=buffer.readLine())!=null)
			{
				System.out.println(line);
			}
			buffer.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
 
 public static void checkpoint()
{

System.out.println("I want a CHKPT after "+qc);
String command="./chkptplugin";

printProcessOutput(runProcess(command));

			
}
  private static void setStatics(String myURL,String user,String pass)
  {
                   
                    URL=myURL;
                    username=user;
                    password=pass;
                    
  }
  public  Connection WrapConnect(String myURL,String user,String pass) throws SQLException
  {
                    setStatics(myURL,user,pass);
  	           // checkpoint();
                    con=DriverManager.getConnection(URL,username,password);
                                 
                    return con;
                       
  }
  public ResultSet WrapExecuteQuery(String query) throws SQLException
  {
  	qc++;
  	//WrapConnect(URL,username,password);
      Statement stmt=con.createStatement();
      return stmt.executeQuery(query);
  }
  public void WrapExecuteUpdate(PreparedStatement preparedstmt) throws SQLException
  {
  	qc++;
  	//WrapConnect(URL,username,password);
 //     con=DriverManager.getConnection(URL,username,password);
     
      //System.out.println("\n\nRUN "+preparedstmt.toString());
      preparedstmt.executeUpdate();
     /* System.out.println("\n\nOUTPUT \n\n");
      ResultSet rs=WrapExecuteQuery("select * from user_details where user_id<5");
      while(rs.next())
      System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(7));
      System.out.println("\n\n\n\n");*/
        checkpoint();
  }
  
public static void main(String args[]){  
CheckpointJava.checkpoint();
try{  
Class.forName("com.mysql.jdbc.Driver");  
}
catch(Exception e)
{
    
}
CheckpointJava wrapObject=new CheckpointJava();

  //  System.out.println("DB");
//here sonoo is database name, root is username and password
 try {wrapObject.WrapConnect( "jdbc:mysql://localhost:3306/LARGE?useSSL=false","root","J!4192chb");
 
 }
  catch(Exception e)
    {
        
    }

 
//Random randomGenerator = new Random();
//int randomInt = randomGenerator.nextInt(100);
Scanner sc=null;
try{
sc=new Scanner(new File("query_file"));
}
catch (IOException e)
{

}
int i=1;
while(sc.hasNext())
{
    try {
       wrapObject.WrapConnect( "jdbc:mysql://localhost:3306/LARGE"+"?useSSL=false","root","J!4192chb");
       String query ;
       query=sc.nextLine();
       String command_called=query.split(" ")[0];
      
       //for(int randele=0;randele<150000;randele++)System.out.println(randele);
        System.out.println("Your query was : "+query);
       System.out.println("Your command was :"+command_called.toLowerCase());
       if(command_called.toLowerCase().equals("update"))
       {
       PreparedStatement preparedStmt = con.prepareStatement(query);
       wrapObject.WrapExecuteUpdate(preparedStmt);
       }
       else
       {
      // 	System.out.println("Command was **"+command_called.toLowerCase()+"**  instead of update");
        ResultSet rs=wrapObject.WrapExecuteQuery("select * from user_details where user_id="+i);
        while(rs.next())
        System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(7));
        //for(int randele=0;randele<150000;randele++)System.out.println(randele);
        
        }
       System.out.println("Executing i="+i+"");
       i++;
      
    }

    catch(Exception e)
    {
        
    }
}
sc.close();
}
}  
 
