if [ $# -eq 2 ]
then
gcc $1 -o $2  `mysql_config --cflags --libs`
else 
	if [ $# -eq 1 ]
	then
	cc $1.c -o $1  `mysql_config --cflags --libs`
	fi
fi

